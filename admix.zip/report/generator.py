from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.db.models import Count, Sum, F, Q, Value, DecimalField
from django.db.models.functions import Coalesce, TruncDate, TruncWeek, TruncMonth
from django.utils import timezone

from orders.models import Order, OrderItem1, OrderItem2

import enum


class Period(enum.StrEnum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "montly"


@dataclass(frozen=True)
class ReportRow:
    Period: str
    NewUsers: int
    ActivatedUsers: int
    OrdersCount: int
    OrderItem1Count: int
    OrderItem1Amount: Decimal
    OrderItem2Count: int
    OrderItem2Amount: Decimal
    OrdersTotalAmount: Decimal


def _start_of_period(d: date, period: Period) -> date:
    if period == Period.DAILY:
        return d
    if period == Period.WEEKLY:
        # Monday start
        return d - timedelta(days=d.weekday())
    if period == Period.MONTHLY:
        return d.replace(day=1)
    raise ValueError(f"Unknown period: {period}")


def _add_month(d: date) -> date:
    y, m = d.year, d.month
    if m == 12:
        return date(y + 1, 1, 1)
    return date(y, m + 1, 1)


def _build_periods(start: date, end: date, period: Period) -> list[date]:
    start_p = _start_of_period(start, period)
    end_p = _start_of_period(end, period)

    periods: list[date] = []
    cur = start_p
    while cur <= end_p:
        periods.append(cur)
        if period == "daily":
            cur = cur + timedelta(days=1)
        elif period == "weekly":
            cur = cur + timedelta(weeks=1)
        else:  # monthly
            cur = _add_month(cur)
    return periods


def _ensure_range_coverage(start: date, end: date) -> tuple[datetime, datetime]:
    start_naive = datetime.combine(start, datetime.min.time())
    end_excl_naive = datetime.combine(end + timedelta(days=1), datetime.min.time())

    if timezone.is_aware(timezone.now()):
        return timezone.make_aware(start_naive), timezone.make_aware(end_excl_naive)
    return start_naive, end_excl_naive


def _trunc(period: Period):
    if period == Period.DAILY:
        return TruncDate
    if period == Period.WEEKLY:
        return TruncWeek
    if period == Period.MONTHLY:
        return TruncMonth
    raise ValueError(f"Unknown period: {period}")


def generate_user_orders_report(*, start: date=None, end: date=None, period: Period=None) -> list[ReportRow]:
    print("hehe")
    print(list(get_user_model().objects.with_stats()))
    return
    if end < start:
        raise ValueError("end must be >= start")

    periods = _build_periods(start, end, period)
    start_dt, end_dt_excl = _ensure_range_coverage(start, end)

    zero_money = Decimal("0.00")
    data = {
        p: {
            "NewUsers": 0,
            "ActivatedUsers": 0,
            "OrdersCount": 0,
            "OrderItem1Count": 0,
            "OrderItem1Amount": zero_money,
            "OrderItem2Count": 0,
            "OrderItem2Amount": zero_money,
        }
        for p in periods
    }

    trunc = _trunc(period)

    user_rows = (
        get_user_model()
        .with_stats()
    )
    user_rows = (
        get_user_model()
        .filter(date_joined__gte=start_dt, date_joined__lt=end_dt_excl)
        .annotate(p=trunc("date_joined"))
        .values("p")
        .annotate(
            new_users=Count("id"),
            activated_users=Count("id", filter=Q(is_active=True)),
        )
    )

    for r in user_rows:
        p = _start_of_period(r["p"].date(), period)
        data[p]["NewUsers"] = int(r["new_users"] or 0)
        data[p]["ActivatedUsers"] = int(r["activated_users"] or 0)

    out: list[ReportRow] = []
    for p in periods:
        total = (
            (data[p]["OrderItem1Amount"] or zero_money)
            + (data[p]["OrderItem2Amount"] or zero_money)
        )
        out.append(
            ReportRow(
                Period=p.isoformat(),
                NewUsers=data[p]["NewUsers"],
                ActivatedUsers=data[p]["ActivatedUsers"],
                OrdersCount=data[p]["OrdersCount"],
                OrderItem1Count=data[p]["OrderItem1Count"],
                OrderItem1Amount=data[p]["OrderItem1Amount"],
                OrderItem2Count=data[p]["OrderItem2Count"],
                OrderItem2Amount=data[p]["OrderItem2Amount"],
                OrdersTotalAmount=total,
            )
        )

    return out























def jija():
    order_rows = (
        Order.objects
        .filter(created_at__gte=start_dt, created_at__lt=end_dt_excl)
        .annotate(p=trunc("created_at"))
        .values("p")
        .annotate(c=Count("id"))
    )

    for r in order_rows:
        p = _start_of_period(r["p"].date(), period)
        data[p]["OrdersCount"] = int(r["c"] or 0)

    # --- OrderItem1 count + amount ---
    item1_rows = (
        OrderItem1.objects
        .filter(created_at__gte=start_dt, created_at__lt=end_dt_excl)
        .annotate(p=trunc("created_at"))
        .values("p")
        .annotate(
            c=Count("id"),
            amt=Coalesce(
                Sum("price"),
                Value(Decimal("0.00")),
                output_field=DecimalField(max_digits=18, decimal_places=2),
            ),
        )
    )

    for r in item1_rows:
        p = _start_of_period(r["p"].date(), period)
        data[p]["OrderItem1Count"] = int(r["c"] or 0)
        data[p]["OrderItem1Amount"] = r["amt"] or zero_money

    # --- OrderItem2 count + amount (placement_price + article_price) ---
    item2_rows = (
        OrderItem2.objects
        .filter(created_at__gte=start_dt, created_at__lt=end_dt_excl)
        .annotate(p=trunc("created_at"))
        .values("p")
        .annotate(
            c=Count("id"),
            amt=Coalesce(
                Sum(F("placement_price") + F("article_price")),
                Value(Decimal("0.00")),
                output_field=DecimalField(max_digits=18, decimal_places=2),
            ),
        )
    )

    for r in item2_rows:
        p = _start_of_period(r["p"].date(), period)
        data[p]["OrderItem2Count"] = int(r["c"] or 0)
        data[p]["OrderItem2Amount"] = r["amt"] or zero_money
