from datetime import datetime, timedelta
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Dict, Any, Union, List

from django.core.management.base import BaseCommand, CommandError
from django.db.models import Sum, Q, Count
from django.utils.timezone import make_aware

from core.models import User

# Constants
PERIOD_DAILY = "daily"
PERIOD_WEEKLY = "weekly"
PERIOD_MONTHLY = "monthly"
PERIODS = (PERIOD_DAILY, PERIOD_WEEKLY, PERIOD_MONTHLY)

TABLE_HEADERS = [
    ("Period", 12), ("NewUsers", 8), ("Activated", 9), ("Orders", 6),
    ("It1Cnt", 6), ("It1Amt", 10), ("It2Cnt", 6), ("It2Amt", 10), ("TotalAmt", 10)
]


@dataclass
class ReportRow:
    new_users: int = 0
    activated_users: int = 0
    orders_count: int = 0
    item1_count: int = 0
    item1_amount: Decimal = field(default_factory=lambda: Decimal("0.00"))
    item2_count: int = 0
    item2_amount: Decimal = field(default_factory=lambda: Decimal("0.00"))

    @property
    def total_amount(self) -> Decimal:
        return self.item1_amount + self.item2_amount


class Command(BaseCommand):
    help = "Generates a User & Orders Activity Report"

    def add_arguments(self, parser):
        parser.add_argument("--start", type=str, required=True,
                            help="Start date (YYYY-MM-DD)")
        parser.add_argument("--end", type=str, required=True,
                            help="End date (YYYY-MM-DD)")
        parser.add_argument("--period", type=str,
                            default=PERIOD_DAILY, choices=PERIODS)

    def handle(self, *args, **options):
        # 1. Parse Inputs
        start_str = options.get("start")
        end_str = options.get("end")
        period_key = options.get("period")

        if start_str in (None, "") or end_str in (None, ""):
            raise CommandError("Start and End dates must be provided.")

        try:
            start_date = make_aware(datetime.strptime(start_str, "%Y-%m-%d"))
            end_date_input = datetime.strptime(end_str, "%Y-%m-%d")
            # Ensure end_date covers the full last day
            end_date = make_aware(end_date_input.replace(
                hour=23, minute=59, second=59))
        except ValueError:
            raise CommandError("Dates must be in YYYY-MM-DD format.")

        # 2. Generate Report
        self.stdout.write(
            f"Generating {period_key} report from {start_date.date()} to {end_date.date()}...")

        self._print_table_header()

        # Iterate through the time range
        current = start_date
        while current <= end_date:
            # Calculate the end of the current period
            period_end = self._get_period_end(current, end_date, period_key)

            # Fetch data for this specific slice
            row_data = self._fetch_period_data(current, period_end)

            # Print row
            self._print_row(current, row_data)

            # Move to next period
            current = self._get_next_period_start(current, period_key)

    def _fetch_period_data(self, start: datetime, end: datetime) -> ReportRow:
        """
        Uses the UserQuerySet to aggregate data for a specific time window.

        :param start: Start of the period (inclusive).
        :param end: End of the period (inclusive).
        :return: A populated ReportRow object.
        """
        row = ReportRow()

        # 1. User Acquisition Stats (New & Activated)
        # We query this separately because with_stats() calculates *Activity*,
        # but New Users is about *Registration* (date_joined).
        user_acquisition = User.objects.filter(
            date_joined__range=(start, end)
        ).aggregate(
            new=Count("id"),
            active=Count("id", filter=Q(is_active=True))
        )
        row.new_users = user_acquisition["new"]
        row.activated_users = user_acquisition["active"]

        # 2. Activity Stats (Orders & Items)
        # We use the custom UserQuerySet.with_stats() to annotate users with their
        # activity *in this period*, then aggregate those annotations globally.
        activity_stats = User.objects.all().with_stats(
            timestamp_start=start,
            timestamp_end=end
        ).aggregate(
            orders=Sum("orders_count"),
            i1_cnt=Sum("items1_count"),
            i1_amt=Sum("items1_spent"),
            i2_cnt=Sum("items2_count"),
            i2_amt=Sum("items2_spent")
        )

        # Map aggregation results to ReportRow
        # The 'or 0' is necessary because Sum() returns None if no rows match
        row.orders_count = activity_stats["orders"] or 0
        row.item1_count = activity_stats["i1_cnt"] or 0
        row.item1_amount = activity_stats["i1_amt"] or Decimal("0.00")
        row.item2_count = activity_stats["i2_cnt"] or 0
        row.item2_amount = activity_stats["i2_amt"] or Decimal("0.00")

        return row

    def _get_period_end(self, current: datetime, global_end: datetime, period_type: str) -> datetime:
        """Calculates the end timestamp for the current period."""
        if period_type == PERIOD_DAILY:
            end_of_period = current.replace(hour=23, minute=59, second=59)
        elif period_type == PERIOD_WEEKLY:
            # TODO: not assuming 7 days from now, but this for later
            # End of the week (assuming roughly 7 days from current)
            end_of_period = (current + timedelta(days=6)).replace(hour=23, minute=59, second=59)
        elif period_type == PERIOD_MONTHLY:
            # Logic to find the last day of the current month
            if current.month == 12:
                next_month = current.replace(year=current.year + 1, month=1, day=1)
            else:
                next_month = current.replace(month=current.month + 1, day=1)
            end_of_period = (next_month - timedelta(days=1)).replace(hour=23, minute=59, second=59)
        else:
            end_of_period = global_end

        return min(end_of_period, global_end)

    def _get_next_period_start(self, current: datetime, period_type: str) -> datetime:
        """Calculates the start date of the next period."""
        if period_type == PERIOD_DAILY:
            return current + timedelta(days=1)
        elif period_type == PERIOD_WEEKLY:
            return current + timedelta(weeks=1)
        elif period_type == PERIOD_MONTHLY:
            if current.month == 12:
                return current.replace(year=current.year + 1, month=1, day=1)
            else:
                return current.replace(month=current.month + 1, day=1)
        return current + timedelta(days=1)

    def _print_table_header(self) -> None:
        header_str = " | ".join(f"{h[0]:<{h[1]}}" for h in TABLE_HEADERS)
        self.stdout.write(header_str)
        self.stdout.write("-" * len(header_str))

    def _print_row(self, date_obj: datetime, row: ReportRow) -> None:
        key = date_obj.strftime("%Y-%m-%d")
        self.stdout.write(
            f"{key:<12} | "
            f"{row.new_users:<8} | "
            f"{row.activated_users:<9} | "
            f"{row.orders_count:<6} | "
            f"{row.item1_count:<6} | "
            f"{row.item1_amount:<10.2f} | "
            f"{row.item2_count:<6} | "
            f"{row.item2_amount:<10.2f} | "
            f"{row.total_amount:<10.2f}"
        )
