from rest_framework.test import APITestCase

from django.test import TestCase
from report.generator import generate_user_orders_report

# Create your tests here.


class TestReport(TestCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()

    def test_jija(self):
        generate_user_orders_report()
