from orders.models import Order, OrderItem2, OrderItem1

from django.contrib.auth.models import UserManager
from django.db import models
from django.db.models import Count, Sum, F, OuterRef, Subquery, Value, Q
from django.db.models.functions import Coalesce

from typing import Optional
from datetime import datetime


class UserQuerySet(models.QuerySet):

    def with_stats(
        self,
        *,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
    ) -> "UserQuerySet":
        def _dt_kwargs(prefix: str) -> dict:
            kwargs = {}
            if start_dt is not None:
                kwargs[f"{prefix}__gte"] = start_dt
            if end_dt is not None:
                kwargs[f"{prefix}__lt"] = end_dt
            return kwargs

        order_dt = _dt_kwargs("created_at")
        item1_dt = _dt_kwargs("created_at")
        item2_dt = _dt_kwargs("created_at")

        money_field = models.DecimalField(max_digits=18, decimal_places=2)
        zero_money = Value(0, output_field=money_field)

        # IMPORTANT trick:
        # .values() with NO fields => single-row aggregate => NO GROUP BY
        # .order_by() clears ordering (subqueries shouldn't keep model default ordering)

        orders_count_sq = (
            Order.objects
            .filter(user=OuterRef("pk"))
            .filter(**order_dt)
            .order_by()
            .values()
            .annotate(c=Count("id"))
            .values("c")
        )

        items1_count_sq = (
            OrderItem1.objects
            .filter(order__user=OuterRef("pk"))
            .filter(**item1_dt)
            .order_by()
            .values()
            .annotate(c=Count("id"))
            .values("c")
        )

        items1_spent_sq = (
            OrderItem1.objects
            .filter(order__user=OuterRef("pk"))
            .filter(**item1_dt)
            .order_by()
            .values()
            .annotate(s=Sum("price"))
            .values("s")
        )

        items2_count_sq = (
            OrderItem2.objects
            .filter(order__user=OuterRef("pk"))
            .filter(**item2_dt)
            .order_by()
            .values()
            .annotate(c=Count("id"))
            .values("c")
        )

        items2_spent_sq = (
            OrderItem2.objects
            .filter(order__user=OuterRef("pk"))
            .filter(**item2_dt)
            .order_by()
            .values()
            .annotate(s=Sum(F("placement_price") + F("article_price")))
            .values("s")
        )

        return self.annotate(
            orders_count=Coalesce(Subquery(orders_count_sq[:1], output_field=models.IntegerField()), Value(0)),

            items1_count=Coalesce(Subquery(items1_count_sq[:1], output_field=models.IntegerField()), Value(0)),
            items1_spent=Coalesce(Subquery(items1_spent_sq[:1], output_field=money_field), zero_money),

            items2_count=Coalesce(Subquery(items2_count_sq[:1], output_field=models.IntegerField()), Value(0)),
            items2_spent=Coalesce(Subquery(items2_spent_sq[:1], output_field=money_field), zero_money),
        )


class UserManagerQS(UserManager.from_queryset(UserQuerySet)):
    pass
